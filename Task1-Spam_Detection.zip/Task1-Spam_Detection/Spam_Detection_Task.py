# --- Code Cell ---
import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

# --- Code Cell ---
nltk.download('stopwords')

# --- Code Cell ---
Stemmer=PorterStemmer()
stop_words=set(stopwords.words("english"))

# --- Code Cell ---
data=pd.read_csv("spam_ham_dataset.csv",encoding="latin-1")
data.head()

# --- Code Cell ---
print(data.columns)

# --- Code Cell ---
X = data.drop('label_num', axis=1)  # Replace 'target_column' with your label column name
y = data['label_num']

# --- Code Cell ---
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(data['text'])  # Replace 'message' with your actual column

# --- Code Cell ---
model = LogisticRegression()

# --- Code Cell ---
# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Fit your model
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# --- Code Cell ---
print(f"Accuracy:{accuracy_score(y_test,y_pred)*100:.2f}%")
print("\nClassification Report:")
print(classification_report(y_test,y_pred))

# --- Code Cell ---

# ========================================
# Spam Detection with Tkinter GUI
# ========================================

import pandas as pd
import string
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, accuracy_score
import tkinter as tk
from tkinter import messagebox

nltk.download('stopwords')

# Load dataset
data = pd.read_csv('spam_ham_dataset.csv')
data = data[['label', 'text']]

# Text preprocessing
ps = PorterStemmer()
stop_words = set(stopwords.words('english'))

def preprocess_text(text):
    text = text.lower()
    text = "".join([char for char in text if char not in string.punctuation])
    words = text.split()
    words = [ps.stem(word) for word in words if word not in stop_words]
    return " ".join(words)

data['text'] = data['text'].apply(preprocess_text)

# Encode labels
le = LabelEncoder()
data['label'] = le.fit_transform(data['label'])

# Feature extraction
tfidf = TfidfVectorizer()
X = tfidf.fit_transform(data['text'])
y = data['label']

# Train test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model training
model = LogisticRegression()
model.fit(X_train, y_train)

# Evaluation (optional)
y_pred = model.predict(X_test)
print(f"Accuracy: {accuracy_score(y_test, y_pred)*100:.2f}%")
print("Classification Report:\n", classification_report(y_test, y_pred))

# ========================================
# GUI with Tkinter
# ========================================

def detect_spam():
    msg = entry.get("1.0", tk.END)
    msg_cleaned = preprocess_text(msg)
    vector = tfidf.transform([msg_cleaned])
    prediction = model.predict(vector)
    result = 'Spam' if prediction[0] == 1 else 'Ham'
    messagebox.showinfo("Prediction", f"The message is: {result}")

# Create GUI window
root = tk.Tk()
root.title("Spam Detector")
root.geometry("400x300")

label = tk.Label(root, text="Enter a message:", font=("Helvetica", 12))
label.pack(pady=10)

entry = tk.Text(root, height=5, width=40)
entry.pack(pady=10)

button = tk.Button(root, text="Detect", command=detect_spam, bg="blue", fg="white")
button.pack(pady=10)

root.mainloop()


